package com.learn2crack.tab;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TabHost;

@SuppressLint("NewApi") public class MainActivity extends FragmentActivity {
	ViewPager Tab;
    TabPagerAdapter TabAdapter;
	ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TabAdapter = new TabPagerAdapter(getSupportFragmentManager());
        
        Tab = (ViewPager)findViewById(R.id.pager);        
        Tab.setOnPageChangeListener(
                new ViewPager.SimpleOnPageChangeListener() {
                    @Override
                    public void onPageSelected(int position) {
                    	actionBar = getActionBar();
                    	actionBar.setSelectedNavigationItem(position);                    
                    	}                    
                });
        Tab.setAdapter(TabAdapter);
        
        actionBar = getActionBar();        
        //Enable Tabs on Action Bar
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00C4CD")));
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        ActionBar.TabListener tabListener = new ActionBar.TabListener()
        {

			@Override
			public void onTabReselected(android.app.ActionBar.Tab tab,
					FragmentTransaction ft) {
				// TODO Auto-generated method stub
				
			}

			@Override
			 public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
				
				getActionBar().show();
				actionBar.setTitle("Diabetes Tracker");
				actionBar.setSubtitle("Transforming Care Beyond Walls..!");
				//getActionBar().hide();
				//getActionBar().setCustomView(R.layout.information);
				getActionBar().setIcon(R.drawable.hcllogo);
				Tab.setBackgroundColor(Color.WHITE);
	            Tab.setCurrentItem(tab.getPosition());
	        }

			@Override
			public void onTabUnselected(android.app.ActionBar.Tab tab,
					FragmentTransaction ft) {
				// TODO Auto-generated method stub
				
			}};
			//Add New Tab
			 android.app.ActionBar.Tab Info = actionBar.newTab();
			 Info.setTabListener(tabListener);
			 Info.setText(R.string.InfoI);
			// Info.setCustomView(R.layout.information);
			 actionBar.addTab(Info);
			
			 android.app.ActionBar.Tab GlucoseTrend = actionBar.newTab();
			 GlucoseTrend.setText(R.string.BGI);
			 GlucoseTrend.setTabListener(tabListener);
			 actionBar.addTab(GlucoseTrend);
			
			 android.app.ActionBar.Tab CalorieTrend = actionBar.newTab();
			 CalorieTrend.setText(R.string.Cal1);
			 CalorieTrend.setTabListener(tabListener);
			 actionBar.addTab(CalorieTrend);
			 
			 android.app.ActionBar.Tab Food = actionBar.newTab();
			 Food.setText(R.string.Food1);
			 Food.setTabListener(tabListener);
			 actionBar.addTab(Food);
			 }



    public void setTabColor(TabHost tabhost) {

        for (int i = 0; i < tabhost.getTabWidget().getChildCount(); i++) {
            tabhost.getTabWidget().getChildAt(i)
                    .setBackgroundResource(R.drawable.header_blank); // unselected
        }
        tabhost.getTabWidget().setCurrentTab(0);
        tabhost.getTabWidget().getChildAt(tabhost.getCurrentTab())
                .setBackgroundResource(R.drawable.tab_selected_new); // selected
                                                                        // //have
                                                                        // to
                                                                        // change
    }    
}
