package com.example.tracker;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.FragmentManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.EditText;


public class Android extends Fragment implements OnClickListener{
	private static final int i= 0;
	private EditText fromDateEtxt;
	private DatePickerDialog fromDatePickerDialog;
	private SimpleDateFormat dateFormatter;
	private ImageButton  nextday,prevday;
	private Date date;
public View android ;
	@Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
	        
		android = inflater.inflate(R.layout.android_frag, container, false);
//for setting current date
		dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
		fromDateEtxt = (EditText) android.findViewById(R.id.etxt_fromdate);	
		fromDateEtxt.setInputType(InputType.TYPE_NULL);
		fromDateEtxt.setOnClickListener(this);		
		date = new Date();		
		fromDateEtxt.setText(dateFormatter.format(date));
//for < button to get yesterday date
		prevday =(ImageButton)android.findViewById(R.id.left);
		prevday.setOnClickListener(this);
	
//for > button to get nextday date
				nextday =(ImageButton)android.findViewById(R.id.right);
				nextday.setOnClickListener(this);
		
	        return android;
	        }

	public  String getDate(String  curDate, int day) throws ParseException {
		  final SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
		  final java.util.Date date = format.parse(curDate);
		  final Calendar calendar = Calendar.getInstance();
		  calendar.setTime(date);
		  calendar.add(Calendar.DAY_OF_YEAR, day);
		  return format.format(calendar.getTime()); 
		}	
	
	public String parseDate(String date, String format) throws ParseException
	{
	    SimpleDateFormat formatter = new SimpleDateFormat(format);
	    return formatter.parse(date).toString();
	}
	
	private void showDatePicker() {
        DatePickerFragment date = new DatePickerFragment();
        /**
        * Set Up Current Date Into dialog
        */
        Calendar calender = Calendar.getInstance();
        Bundle args = new Bundle();
        args.putInt("year", calender.get(Calendar.YEAR));
        args.putInt("month", calender.get(Calendar.MONTH));
        args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
        date.setArguments(args);
        /**
        * Set Call back to capture selected date
        */
        date.setCallBack(ondate);
        //FragmentManager fm = getFragmentManager();
     date.show(getActivity().getFragmentManager(), "tag");
    }

    OnDateSetListener ondate = new OnDateSetListener() {

        public void onDateSet(DatePicker view, int year, int monthOfYear,
            int dayOfMonth) {

           // edittext.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear+1)
             //  + "-" + String.valueOf(year));
        }
    };            

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		
		if(v == fromDateEtxt )
			showDatePicker();
		else if( v == prevday)			
			try {
				fromDateEtxt.setText(getDate(fromDateEtxt.getText().toString(),-1));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}						
		else if( v == nextday)
			try {
				fromDateEtxt.setText(getDate(fromDateEtxt.getText().toString(),1));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
}
