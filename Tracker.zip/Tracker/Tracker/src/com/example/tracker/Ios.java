package com.example.tracker;



import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.Arrays;

import com.androidplot.series.XYSeries;
import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYStepMode;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Ios extends Fragment {
	
	private XYPlot xyPlot;
	
	final String[] mMonths = new String[] {
        	"Mon","Tue", "Wed","Thrus", "Fri","Sat",
        	"Sun"
        };

	 @Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
	        View ios = inflater.inflate(R.layout.ios_frag, container, false);
	        //((TextView)ios.findViewById(R.id.textView)).setText("iOS");
	        
	       
	    
	        return ios;
}}
